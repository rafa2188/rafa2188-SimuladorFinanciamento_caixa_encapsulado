import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GeradorPDF {

    // Classe interna para representar uma parcela
    static class Parcela {
        int numero;
        double valor;
        String dataVencimento;

        Parcela(int numero, double valor, String dataVencimento) {
            this.numero = numero;
            this.valor = valor;
            this.dataVencimento = dataVencimento;
        }
    }

    public static void gerarPDF(String nomeCliente, double valorImovel, double valorFinanciado,
                                double totalPagoPrice, double jurosTotaisPrice,
                                double totalPagoSAC, double jurosTotaisSAC,
                                List<Parcela> parcelasSAC, double percentualParcelaPrice,
                                double percentualParcelaSAC) {
        Document document = new Document();

        try {
            // Cria o arquivo PDF
            PdfWriter.getInstance(document, new FileOutputStream("SimulacaoFinanciamento.pdf"));
            document.open();

            // Adiciona um logotipo (opcional)
            try {
                Image logo = Image.getInstance("C:\\Users\\rafael.garcia\\Desktop\\exercicio agi\\SimuladorFinanciamento_caixa_encapsulado\\SimuladorFinanciamento_caixa_encapsulado\\Finaciailogo.jpg"); // Substitua pelo caminho da imagem
                logo.scaleToFit(200, 200);
                logo.setAlignment(Element.ALIGN_CENTER);
                document.add(logo);
            } catch (Exception e) {
                System.err.println("Logotipo não encontrado. Continuando sem o logotipo...");
            }

            // Título do documento
            Font titleFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BaseColor.DARK_GRAY);
            Paragraph title = new Paragraph("Simulação de Financiamento Imobiliário", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            title.setSpacingAfter(20);
            document.add(title);

            // Informações do cliente
            Font headerFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.BLACK);
            Font contentFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.BLACK);

            Paragraph cliente = new Paragraph("Cliente: " + nomeCliente, contentFont);
            cliente.setSpacingAfter(10);
            document.add(cliente);

            // Tabela de resumo da simulação
            PdfPTable resumoTable = new PdfPTable(2);
            resumoTable.setWidthPercentage(100);
            resumoTable.setSpacingBefore(10);
            resumoTable.setSpacingAfter(10);

            addTableHeader(resumoTable, headerFont);
            addTableRow(resumoTable, "Valor do Imóvel", "R$ " + String.format("%.2f", valorImovel), contentFont);
            addTableRow(resumoTable, "Valor Financiado", "R$ " + String.format("%.2f", valorFinanciado), contentFont);
            addTableRow(resumoTable, "Total Pago (Price)", "R$ " + String.format("%.2f", totalPagoPrice), contentFont);
            addTableRow(resumoTable, "Juros Totais (Price)", "R$ " + String.format("%.2f", jurosTotaisPrice), contentFont);
            addTableRow(resumoTable, "Total Pago (SAC)", "R$ " + String.format("%.2f", totalPagoSAC), contentFont);
            addTableRow(resumoTable, "Juros Totais (SAC)", "R$ " + String.format("%.2f", jurosTotaisSAC), contentFont);

            document.add(resumoTable);

            // Tabela de parcelas (SAC)
            Paragraph parcelasTitle = new Paragraph("Tabela de Parcelas (SAC)", headerFont);
            parcelasTitle.setSpacingBefore(20);
            parcelasTitle.setSpacingAfter(10);
            document.add(parcelasTitle);

            PdfPTable parcelasTable = new PdfPTable(3);
            parcelasTable.setWidthPercentage(100);
            parcelasTable.setSpacingBefore(10);
            parcelasTable.setSpacingAfter(20);

            addTableHeader(parcelasTable, "Parcela", "Valor", "Data Vencimento", headerFont);

            // Adiciona todas as parcelas à tabela
            for (Parcela parcela : parcelasSAC) {
                addTableRow(parcelasTable,
                        String.valueOf(parcela.numero),
                        "R$ " + String.format("%.2f", parcela.valor),
                        parcela.dataVencimento,
                        contentFont);
            }

            document.add(parcelasTable);

            // Análise de viabilidade
            Paragraph analiseTitle = new Paragraph("Análise de Viabilidade", headerFont);
            analiseTitle.setSpacingBefore(20);
            analiseTitle.setSpacingAfter(10);
            document.add(analiseTitle);

            if (percentualParcelaPrice > 30) {
                document.add(new Paragraph("⚠️ A parcela do sistema Price ultrapassa 30% da sua renda mensal. Verifique se é viável para você.", contentFont));
            } else {
                document.add(new Paragraph("✅ A parcela do sistema Price está dentro de 30% da sua renda mensal.", contentFont));
            }

            if (percentualParcelaSAC > 30) {
                document.add(new Paragraph("⚠️ A parcela inicial do sistema SAC ultrapassa 30% da sua renda mensal. Verifique se é viável para você.", contentFont));
            } else {
                document.add(new Paragraph("✅ A parcela inicial do sistema SAC está dentro de 30% da sua renda mensal.", contentFont));
            }

            // Rodapé
            Paragraph rodape = new Paragraph("\n\nEste documento foi gerado automaticamente pelo sistema de simulação de financiamento.", new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC, BaseColor.GRAY));
            rodape.setAlignment(Element.ALIGN_CENTER);
            document.add(rodape);

            System.out.println("PDF gerado com sucesso: SimulacaoFinanciamento.pdf");
        } catch (DocumentException | IOException e) {
            System.err.println("Erro ao gerar o PDF: " + e.getMessage());
        } finally {
            document.close();
        }
    }

    // Método para adicionar cabeçalho da tabela
    private static void addTableHeader(PdfPTable table, Font font) {
        String[] headers = {"Descrição", "Valor"};
        for (String header : headers) {
            PdfPCell cell = new PdfPCell(new Phrase(header, font));
            cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);
        }
    }

    // Método para adicionar linha na tabela
    private static void addTableRow(PdfPTable table, String col1, String col2, Font font) {
        table.addCell(new Phrase(col1, font));
        table.addCell(new Phrase(col2, font));
    }

    // Método para adicionar cabeçalho da tabela de parcelas
    private static void addTableHeader(PdfPTable table, String col1, String col2, String col3, Font font) {
        PdfPCell cell1 = new PdfPCell(new Phrase(col1, font));
        PdfPCell cell2 = new PdfPCell(new Phrase(col2, font));
        PdfPCell cell3 = new PdfPCell(new Phrase(col3, font));
        cell1.setBackgroundColor(BaseColor.LIGHT_GRAY);
        cell2.setBackgroundColor(BaseColor.LIGHT_GRAY);
        cell3.setBackgroundColor(BaseColor.LIGHT_GRAY);
        table.addCell(cell1);
        table.addCell(cell2);
        table.addCell(cell3);
    }

    // Método para adicionar linha na tabela de parcelas
    private static void addTableRow(PdfPTable table, String col1, String col2, String col3, Font font) {
        table.addCell(new Phrase(col1, font));
        table.addCell(new Phrase(col2, font));
        table.addCell(new Phrase(col3, font));
    }


}